sommelier-bot/
├── config.js         # Все настройки (БД, API ключи)
├── locales/          # Переводы (en.json, ru.json)
├── src/
│   ├── bot/          # Логика бота
│   │   ├── telegram.js  # TG обработчики
│   │   ├── vk.js        # VK обработчики
│   │   └── commands/    # Общие команды (/search, /price)
│   │
│   ├── models/       # Простые схемы Mongoose
│   │   ├── User.js
│   │   └── Recipe.js
│   │
│   ├── services/     # Вся основная логика
│   │   ├── recipes.js    # Поиск, расчет цены
│   │   ├── notifications.js # Уведомления
│   │   └── sync.js       # Синхронизация VK-TG
│   │
│   └── utils/        # Помощники
│       ├── logger.js
│       └── price.js  # Расчет стоимости
│
├── package.json
└── index.js          # Запуск всего