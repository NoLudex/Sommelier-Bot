For install this project, need use .env

Like:
DB_HOST=
DB_USER=
DB_PASSWORD=
DB_NAME=
TELEGRAM_TOKEN=